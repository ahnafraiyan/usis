To prepare the schema:
1. Create tables
2. create sequences


from V4_updates
1. extendPassword.txt
2. sessionCurrenttable
3. insert teacher 
4. insert admin
5. insert student
6. teaches update
7. Notice table

3. create functions
4. insert rest of data serially
5. create trigger
6. create procedure all

